insertHistory <-
function(type, list) {
    mongo <- connectMongo(Addr="127.0.0.1", DB="HISTORY", port=50000)
    list$TYPE <- type
    list$TIME <- as.character(Sys.time())
    
    insertData(mongo, toupper(list$TYPE), mongo.bson.from.list(list))
    destroyMongo(mongo)
  }
