destroyMongo <-
function(mongo){
    mongo.destroy(mongo)
  }
