getDBinfo <-
function(Service_id){
    doc <- getDocument(Service_id)
    
    return(doc$db_info)
  }
