cems.startRSlave <-
function(injson, Service_id) {  
    Debugging(injson, Service_id, text="startSlave(injson, Service_id): ")
    print("***************************************")
    print("*                                     *")
    print("*           Analysis Thread           *")
    print("*                                     *")
    print("***************************************")
    doc <- getDocument(Service_id)
    DBinfos <- getDBinfo(Service_id)
    map <- data.frame()
    assign(paste("input", sep="."), injson, envir=.GlobalEnv)
    
    
    
    for(i in DBinfos) { 
      DBconnect <- connectMongo(Addr=Public_DB_Host,
                                DB=as.character(i$db),
                                port=Public_DB_Port)
      
      data <- getAllData(mongo=DBconnect, collection=as.character(i$collection), sort=as.character(i$order))
      data <- subset(data, select=as.character(i$attr))
      data <- as.data.frame(data)
      
      name <- paste(Service_id, i$collection, "data", sep=".")
      data <- cems.restoreDataType(data)
      
      assign(name, data, envir=.GlobalEnv)
      map <- rbind(map, name)
      destroyMongo(DBconnect)
    }
    names(map) <- c("data")
    assign(paste(Service_id, "map", sep="."), map, envir=.GlobalEnv)
    
    cems.startAnalysis(injson=injson, Service_id=Service_id)
  }
