getRequirement <-
function(Service_id) {
    doc <- getDocument(Service_id)
    doc <- doc$requirement
    doc <- doc[[1]]
    return(doc)
  }
