cems.startRMaster <-
  function (json_str) {
    # 초기화
    cems.init()
    
    #   Debugging(json_str, text="startMaster(json_str): ")
    print("****************************************")
    print("*                                      *")
    print("*            Analysis Start            *")
    print("*                                      *")
    print("****************************************")
    
    # input JSON assign
    input <- fromJSON(json_str)
    data <- as.list(unlist(input$sensors_data))
    
    # Mongo DB Connection
    Service_DB <- connectMongo(Addr=Service_DB_Host,
                               DB=Service_DB_Name,
                               port=Service_DB_Port)
    TG_DB <- connectMongo(Addr=User_DB_Host,
                          DB=User_DB_Name)
    
    # get Thin-gateway Data from DB-
    tgdf <- getPartData(TG_DB, TG_id, "service")
    tgdf <- unique(tgdf)
    
    res <- list()
    
    # Service id list 
    for(i in tgdf$service) {
      id <- as.character(i)
      
      servdf <- getRequirement(id)
      servdf <- servdf$sensor
      if(is.include(servdf, names(data))){
        res <- rbind(res, as.character(id))
      }
    }
    res <- unique(res)
    service <- as.list(res)
    
    list <- ls(envir=.GlobalEnv)
    
    if(length(service) == 0)
      stop("Not Maching Service")
    
    log <- list()
    log$service <- service
    log$LOG <- "service"
    #     insertHistory(collection=input$tg_id, list=log)
    
    for(i in 1:nrow(service)) {
      if(!is.integer0(grep(x=nodelist[[1]], pattern="[:]"))) {
        rs <- RS.connect( host=unlist(strsplit(unlist(nodelist), split=":"))[1],
                          port=unlist(strsplit(unlist(nodelist), split=":"))[2] )
      }else{
        rs <- RS.connect( host=nodelist[[1]] )      
      }
      Servid <- as.character(service[i,1])
      RS.eval(rs, require(CEMS))
      RS.eval(rs, CEMS::.init())
      for(name in list) {
        RS.assign(rs, name, get(name))
      }
      RS.assign(rs, "json_str", json_str)
      RS.assign(rs, "Service_id", Servid)
      RS.eval(rs, x=cems.startRSlave(injson=json_str, Service_id=Service_id), wait=FALSE)
      
      RS.close(rs)
    }
  }
