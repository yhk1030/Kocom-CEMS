getPartData <-
function(mongo, collection, attr){
    data <- getAllData(mongo, collection, mongo.bson.empty())
    data <- as.data.frame(data)
    tryCatch({
      frame <- subset(data, select=attr)
    }, error= function(e){
      stop(paste("Error", e, sep = ":"))
    })
    return (frame)
  }
