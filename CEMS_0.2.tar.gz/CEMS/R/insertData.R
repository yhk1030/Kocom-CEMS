insertData <-
function(mongo, collection, bson) {
    ns <- paste(attr(mongo, "db"), collection, sep=".")
    mongo.insert(mongo, ns, bson)
  }
