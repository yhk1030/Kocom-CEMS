is.integer0 <-
function(x) {
    is.integer(x) && length(x) == 0L
  }
