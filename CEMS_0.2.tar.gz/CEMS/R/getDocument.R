getDocument <-
function(Service_id){
    #   Debugging(Service_id, text="getDocument(Service_id): ")
    
    Service_DB <- connectMongo(Addr=Service_DB_Host,
                               DB=Service_DB_Name,
                               port=Service_DB_Port)
    buf <- mongo.bson.buffer.create()
    mongo.bson.buffer.append(buf, "service_id", Service_id)
    buf <- mongo.bson.from.buffer(buf)
    
    cursor <- mongo.find(mongo=Service_DB, ns=paste(attr(Service_DB, "db"), "service", sep="."), query=buf, fields='{"_id":0}')
    
    doc <- mongo.cursor.to.list(cursor)
    if(length(doc) == 0)
      return("No Service")
    
    doc <- doc[[1]]
    return(doc)
  }
