cems.startAnalysis <-
function(injson, Service_id) { 
    cems.continueAnalysis(injson=injson, Service_id=Service_id, index="1")
  }
