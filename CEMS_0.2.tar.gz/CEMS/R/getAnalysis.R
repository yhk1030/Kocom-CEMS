getAnalysis <-
function(Service_id) {
    doc <- getDocument(Service_id)
    
    return(doc$analysis)
  }
